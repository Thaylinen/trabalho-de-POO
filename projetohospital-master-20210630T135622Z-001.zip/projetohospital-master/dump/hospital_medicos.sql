CREATE TABLE `medicos` (
  `id_medicos` int NOT NULL AUTO_INCREMENT,
  `nome_medicos` varchar(100) NOT NULL,
  `crm_medicos` varchar(8) NOT NULL,
  `especialidade_medicos` varchar(50) NOT NULL,
  `salario_medicos` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id_medicos`)
)
